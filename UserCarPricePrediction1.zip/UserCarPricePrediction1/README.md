🚗 CarWise – Used Car Price Prediction System
📌 Project Overview
CarWise is a Machine Learning-based web application developed to predict the selling price of used cars.
The system uses historical used car data and Machine Learning algorithms to estimate the price of a car based on different features such as manufacturing year, kilometers driven, fuel type, seller type, transmission, and owner details.
The application provides an interactive dashboard using Streamlit.
🎯 Project Objectives
•	To predict the selling price of used cars.
•	To understand and analyze used car datasets.
•	To apply Machine Learning algorithms for price prediction.
•	To compare different Machine Learning models.
•	To provide an easy-to-use web application.
🛠️ Technologies Used
•	Python
•	Pandas
•	NumPy
•	Scikit-learn
•	Streamlit
•	Matplotlib
•	Seaborn
•	Joblib
📂 Dataset Information
Dataset Name: CAR DETAILS FROM CAR DEKHO.csv
The dataset contains information about used cars.
Dataset Features
Feature	Description
name	Car name
year	Manufacturing year
selling_price	Selling price of the car
km_driven	Kilometers driven
fuel	Fuel type
seller_type	Type of seller
transmission	Transmission type
owner	Previous owner details
Original Dataset Size: 4340 rows and 8 columns.
🤖 Machine Learning Algorithms
The project uses the following algorithms:
1.	Linear Regression
2.	Decision Tree Regressor
3.	Random Forest Regressor
These algorithms are used to train and evaluate the model for predicting used car prices.
📊 Data Preprocessing
The following preprocessing steps are performed:
•	Checking missing values.
•	Removing duplicate records.
•	Selecting relevant features.
•	Encoding categorical variables.
•	Splitting data into training and testing sets.
•	Training Machine Learning models.
📈 Model Evaluation
The models are evaluated using:
•	Mean Absolute Error (MAE)
•	R² Score
These evaluation metrics help measure the performance of the prediction models.
✨ Application Features
CarWise provides the following sections:
1.	Home: Introduction to the project.
2.	Dataset Explorer: View and explore the dataset.
3.	Data Analysis: Visualize and understand data patterns.
4.	Price Prediction: Predict used car selling prices.
5.	Model Performance: View model evaluation results.
6.	About Project: Information about the project.
💻 Installation and Execution
Step 1: Install Python
Install Python on your computer.
Step 2: Install Required Libraries
Open the terminal in the project folder and execute:
pip install -r requirements.txt
Step 3: Run the Application
Execute the following command:
streamlit run app.py
Step 4: Open the Application
After running the command, Streamlit will open the application in your web browser.
If it does not open automatically, visit:
http://localhost:8501
📸 Project Screenshots
Screenshots of the application are available in the screenshots folder.
📁 Project Structure
UsedCarPricePrediction/
│
├── app.py
├── train_model.py
├── CAR DETAILS FROM CAR DEKHO.csv
├── requirements.txt
├── README.md
│
├── model/
├── screenshots/
└── Project_Report.pdf
Note: Update the project structure according to the actual files in your project folder.
🎓 Project Purpose
This project is developed as an academic Machine Learning Final Project to demonstrate the practical implementation of Machine Learning algorithms and data analysis techniques.
👩‍💻 Conclusion
CarWise demonstrates how Machine Learning can be used to estimate used car selling prices based on historical data. It provides an interactive platform for exploring car data and predicting prices.
________________________________________
Project Name: Used Car Price Prediction System
Application Name: CarWise
Domain: Machine Learning
Language: Python

